#include <stdio.h>
#include <syscall.h>

int 
main(int argc UNUSED, const char* argv[] UNUSED)
{
  printf("Not implemented.\n");  
  return EXIT_SUCCESS;
}
