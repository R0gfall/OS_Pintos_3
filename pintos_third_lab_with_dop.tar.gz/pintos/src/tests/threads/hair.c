/*
  File for 'hair' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "devices/timer.h"

struct semaphore critical_section_chair;
struct semaphore hairdresser_barber;
int cnt;

static void init(void)
{
  sema_init(&hairdresser_barber, 0);
  sema_init(&critical_section_chair, 1);
  cnt = 0;
}

static void hairdresser(void* arg UNUSED)
{
    msg("\n<<<<<hairdresser created>>>>>\n");

    sema_down(&hairdresser_barber);
    while(true){
        cnt--;
        msg(">>> barber start cut >>> %llu", timer_ticks());
        timer_sleep(10);
        sema_up(&critical_section_chair);
        
        msg(">>> barber stop cut >>> %llu", timer_ticks());
        
        if (cnt == 0) {
          sema_down(&hairdresser_barber);
          //sema_down(&critical_section_chair);
          //sema_down(&critical_section_chair);
        }
    }

}

static void client(void* arg UNUSED)
{
    msg("\n<<<<<client %d created>>>>>\n", (int) arg);

    cnt++;
    if(sema_try_down(&critical_section_chair)){
      sema_up(&hairdresser_barber);
      msg(">>> client %d go to barber >>> %llu", (int) arg, timer_ticks());
      return;
    }
    msg(">>> client %d seat in chair >>> %llu", (int) arg, timer_ticks());
    sema_down(&critical_section_chair);

}

void test_hair(unsigned int num_clients, unsigned int interval)
{
  unsigned int i;
  init();

  thread_create("hairdresser", PRI_DEFAULT, &hairdresser, NULL);

  for(i = 0; i < num_clients; i++)
  {
    char name[32];
    timer_sleep(interval);
    snprintf(name, sizeof(name), "client_%d", i + 1);
    thread_create(name, PRI_DEFAULT, &client, (void*) (i+1) );
  }

  timer_msleep(5000);
  pass();
}
