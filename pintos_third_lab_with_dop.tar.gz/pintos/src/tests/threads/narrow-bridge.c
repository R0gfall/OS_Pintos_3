
/* File for 'narrow_bridge' task implementation.  
   SPbSTU, IBKS, 2017 */

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "narrow-bridge.h"


struct semaphore semaphore_left_normal;
struct semaphore semaphore_right_normal;
struct semaphore semaphore_left_ambulance;
struct semaphore semaphore_right_ambulance;
size_t count_threads_on_bridge;
char max_count_threads;
char flag_first_threads;
char direction_move;
enum car_direction global_flag_reverse_move;
int all_threads_cars;
int numbers_threads[2][2];

// Called before test. Can initialize some synchronization objects.
void narrow_bridge_init(void)
{

	max_count_threads = 2;
	flag_first_threads = 0;
	count_threads_on_bridge = 0;
	direction_move = 1; // 1 - left; 2 - right
	//global_flag_reverse_move = 0; // 1 - left; 2 - right
	all_threads_cars = 0;


	// i: 0 - left; 1 - right 
	// j: 0 - normal car; 1 - embulance
	for (int i = 0; i < 2; i++){
		for (int j = 0; j < 2; j++){
			numbers_threads[i][j] = 0;
		}
	}

	sema_init(&semaphore_left_normal, 0);
	sema_init(&semaphore_right_normal, 0);
	sema_init(&semaphore_left_ambulance, 0);
	sema_init(&semaphore_right_ambulance, 0);
}

void arrive_bridge(enum car_priority prio UNUSED, enum car_direction dir UNUSED)
{

	//printf("%d\n", dir); 
	numbers_threads[dir][prio]++;
	all_threads_cars++;

	//printf(">>>>>>>>>>>>%d, %d\n", all_threads_cars, numbers_threads[dir][prio]);

	if (flag_first_threads == 0){
		global_flag_reverse_move = dir;
	}

	// if (flag_first_threads < 2){
	// 	printf("!!!!!!!!!!!!!!\n");
	// 	switch (prio){
	// 	case car_normal:
	// 		switch (dir){
	// 		case dir_left:
	// 			sema_up(&semaphore_left_normal);
	// 			flag_first_threads++;
	// 			break;
	// 		case dir_right:	
	// 			sema_up(&semaphore_right_normal);
	// 			flag_first_threads++;
	// 			break;
	// 		}
	// 		break;

	// 	case car_emergency:
	// 		switch (dir){
	// 		case dir_left:
	// 			sema_up(&semaphore_left_ambulance);
	// 			flag_first_threads++;
	// 			break;
	// 		case dir_right:
	// 			sema_up(&semaphore_right_ambulance);
	// 			flag_first_threads++;
	// 			break;	
	// 		}
	// 		break;
	// 	}
	// 	//flag_first_threads++;
	// 	count_threads_on_bridge++;

	// 	printf("<<<<<<<<<<<<<<<<%d\n", flag_first_threads);
	// }

	if ((flag_first_threads < 2) && (global_flag_reverse_move == dir)) {
		flag_first_threads++;
		if (dir == dir_left){
			if (prio == car_emergency){
				sema_up(&semaphore_left_ambulance);

			}
			else{
				sema_up(&semaphore_left_normal);
			}
		}
		else{

			if (prio == car_emergency){
				sema_up(&semaphore_right_ambulance);
			}
			else{
				sema_up(&semaphore_right_normal);
			}
		}
		count_threads_on_bridge++;
	}


		//numbers_threads[dir][prio]++;

		if (dir == dir_left){
			if (prio == car_emergency){
				sema_down(&semaphore_left_ambulance);
			}
			else{
				sema_down(&semaphore_left_normal);
			}
		}
		else{

			if (prio == car_emergency){
				sema_down(&semaphore_right_ambulance);
			}
			else{
				sema_down(&semaphore_right_normal);
			}
		}
	


	// else{
	// 	switch (prio){
	// 	case car_emergency:
	// 		switch (dir){
	// 		case dir_left:
	// 			sema_down(&semaphore_left_ambulance);
	// 			break;
	// 		case dir_right:
	// 			sema_down(&semaphore_right_ambulance);
	// 			break;	
	// 		}
	// 		break;
	// 	case car_normal:
	// 		switch (dir){
	// 		case dir_left:
	// 			sema_down(&semaphore_left_normal);

	// 			break;
	// 		case dir_right:	
	// 			sema_down(&semaphore_right_normal);
	// 			break;
	// 		}
	// 		break;

		
	// 	}
	// 	//printf("<<<<<<<<<<<<<<<<<%d\n", flag_first_threads);
	// }

}

void exit_bridge(enum car_priority prio UNUSED, enum car_direction dir UNUSED)
{

	count_threads_on_bridge--;
	numbers_threads[dir][prio]--;
	all_threads_cars--;
	
	//printf("----%d\n", count_threads_on_bridge);
	//printf("%d\n", dir); 



	if (count_threads_on_bridge == 0 && all_threads_cars != 0){

		//printf(">>>>>>>>>>>>>Move new\n");
		//printf("+++\n");
		// if (numbers_threads[0][1] >= numbers_threads[1][1] && numbers_threads[0][1] != 0) global_flag_reverse_move = dir_left;
		// else if (numbers_threads[0][1] < numbers_threads[1][1]) global_flag_reverse_move = dir_right;
		// else if (numbers_threads[0][0] >= numbers_threads[1][0]) global_flag_reverse_move = dir_left;
		// else if (numbers_threads[0][0] < numbers_threads[1][0]) global_flag_reverse_move = dir_right;

		// if (numbers_threads[0][0] >= numbers_threads[1][0]) global_flag_reverse_move = dir_left;
		// else global_flag_reverse_move = dir_right;
		

		if ((numbers_threads[global_flag_reverse_move][car_emergency] < numbers_threads[1 - global_flag_reverse_move][car_emergency]) ||
			((numbers_threads[global_flag_reverse_move][car_emergency] == 0) &&
			(numbers_threads[global_flag_reverse_move][car_emergency] == numbers_threads[1 - global_flag_reverse_move][car_emergency]) &&
			(numbers_threads[global_flag_reverse_move][car_normal] <= numbers_threads[1 - global_flag_reverse_move][car_normal] )
			)){
			global_flag_reverse_move = 1 - global_flag_reverse_move;
		}
		//printf("!!!!!__________!!!!!!!!!!    %d\n", global_flag_reverse_move);
		//printf("><><><><><><>  %d, %d\n", numbers_threads[0][car_normal], numbers_threads[1][car_normal]);


		//Две скорых
		if(numbers_threads[global_flag_reverse_move][1] >= 2){
			if (global_flag_reverse_move == dir_left){
				sema_up(&semaphore_left_ambulance);
				sema_up(&semaphore_left_ambulance);
			}
			else {
				sema_up(&semaphore_right_ambulance);
				sema_up(&semaphore_right_ambulance);
			}
			count_threads_on_bridge = 2;
			//numbers_threads[global_flag_reverse_move][car_emergency] -= 2;
			

		}

		//Одна скорая и одна машина
		else if(numbers_threads[global_flag_reverse_move][1] == 1){
			//printf("--------------\n");
			if (global_flag_reverse_move == dir_left){
				sema_up(&semaphore_left_ambulance);
			}
			else {
				sema_up(&semaphore_right_ambulance);
			}	
			count_threads_on_bridge++;
			//numbers_threads[global_flag_reverse_move][car_emergency]--;
			
			
			if (numbers_threads[global_flag_reverse_move][0] > 0){
				//printf("--------------\n");
				if (global_flag_reverse_move == dir_left){
					sema_up(&semaphore_left_normal);
				}
				else{
					sema_up(&semaphore_right_normal);
				}

				count_threads_on_bridge++;
				//numbers_threads[global_flag_reverse_move][car_normal]--;
				
			}
			
		}



		//Две нормальных машины
		else if(numbers_threads[global_flag_reverse_move][0] >= 2 && numbers_threads[global_flag_reverse_move][1] == 0){
			//printf("--------------\n");
			if (global_flag_reverse_move == dir_left){
				sema_up(&semaphore_left_normal);
				sema_up(&semaphore_left_normal);
			}
			else{
				sema_up(&semaphore_right_normal);
				sema_up(&semaphore_right_normal);
			}

			count_threads_on_bridge = 2;
			//numbers_threads[global_flag_reverse_move][car_normal] -= 2;
			
		}

		//Только одна нормальная машина
		else if(numbers_threads[global_flag_reverse_move][0] == 1 && numbers_threads[global_flag_reverse_move][1] == 0){
			//printf("--------------\n");
			if (global_flag_reverse_move == dir_left){
				sema_up(&semaphore_left_normal);
			}
			else{
				sema_up(&semaphore_right_normal);
			}
			
			count_threads_on_bridge++;
			//numbers_threads[global_flag_reverse_move][car_normal]--;
			
		}



		

	
	}







	// switch (prio){
	// 	case car_normal:
	// 		switch (dir){
	// 		case dir_left:
	// 			sema_up(semaphore_left_normal);
	// 			break;
	// 		case dir_right:	
	// 			sema_up(semaphore_right_normal);
	// 			break;
	// 		}
	// 		break;

	// 	case car_emergency:
	// 		switch (dir){
	// 		case dir_left:
	// 			sema_up(semaphore_left_embulance);
	// 			break;
	// 		case dir_right:
	// 			sema_up(semaphore_right_embulance);
	// 			break;	
	// 		}
	// 		break;
	// 	}
}
